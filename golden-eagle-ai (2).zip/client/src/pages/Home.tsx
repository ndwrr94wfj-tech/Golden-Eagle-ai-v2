import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { startLogin } from "@/const";
import React, { useState, useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col relative z-10">
      {/* Navigation */}
      <nav className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-600 bg-clip-text text-transparent">
              GoldenEagle-ai.developers
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => setLocation("/")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => setLocation("/features")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Features
            </button>
            <button
              onClick={() => setLocation("/pricing")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Pricing
            </button>
            <button
              onClick={() => setLocation("/docs")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Docs
            </button>
            <button
              onClick={() => setLocation("/community")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Community
            </button>

            {isAuthenticated && user ? (
              <div className="flex items-center gap-3">
                <Button
                  onClick={() => setLocation("/profile")}
                  variant="outline"
                  size="sm"
                >
                  {user.email}
                </Button>
                <Button
                  onClick={() => logout()}
                  variant="outline"
                  size="sm"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button
                onClick={() => startLogin()}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                Login
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="flex-1 flex items-center justify-center px-4 py-20">
        <div className="max-w-5xl mx-auto w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Golden Eagle Logo with Effects */}
            <div className="flex justify-center">
              <div className="relative w-full max-w-sm">
                {/* Outer glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full blur-3xl opacity-30 animate-pulse" />
                
                {/* Glowing border frame */}
                <div className="absolute inset-0 border-2 border-purple-500/50 rounded-2xl animate-pulse" 
                     style={{
                       transform: `translateY(${scrollY * 0.3}px)`,
                       transition: 'transform 0.1s ease-out'
                     }} />
                
                {/* Image container */}
                <div className="relative bg-gradient-to-br from-purple-900/20 to-pink-900/20 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30 overflow-hidden"
                     style={{
                       transform: `translateY(${scrollY * 0.2}px) scale(${1 + scrollY * 0.0001})`,
                       transition: 'transform 0.1s ease-out'
                     }}>
                  <img 
                    src="/manus-storage/BCD50036-D4A3-4EEB-A418-5E4895A54366_814bfb2e.jpeg"
                    alt="Golden Eagle AI Logo"
                    className="w-full h-auto drop-shadow-2xl"
                  />
                  
                  {/* Shine effect overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" />
                </div>
              </div>
            </div>

            {/* Right: Text Content */}
            <div className="text-center lg:text-left">
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-300 via-pink-300 to-purple-500 bg-clip-text text-transparent leading-tight">
                Golden Eagle AI
              </h1>

              <p className="text-xl lg:text-2xl text-foreground/80 mb-8 leading-relaxed">
                Powerful, Unrestricted, Intelligent. Your personal AI assistant built for advanced reasoning and deep analysis.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 mb-12 justify-center lg:justify-start">
                {isAuthenticated ? (
                  <Button
                    onClick={() => setLocation("/chat")}
                    size="lg"
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-8 py-6 text-lg"
                  >
                    Start Chatting
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={() => setLocation("/login")}
                      size="lg"
                      className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-8 py-6 text-lg"
                    >
                      Get Started
                    </Button>
                    <Button
                      onClick={() => setLocation("/pricing")}
                      size="lg"
                      variant="outline"
                      className="border-purple-500/30 hover:bg-purple-500/10 font-bold px-8 py-6 text-lg"
                    >
                      View Pricing
                    </Button>
                  </>
                )}
              </div>

              {/* Features */}
              <div className="space-y-3 text-foreground/70">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                  <span>End-to-end encrypted conversations</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                  <span>Bitcoin-only payments for maximum privacy</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                  <span>Advanced AI reasoning and analysis</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 py-20 bg-gradient-to-b from-transparent to-purple-500/5">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
            Why Choose Golden Eagle AI
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm hover:border-purple-500/40 transition-all">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 mb-4 mx-auto" />
              <h3 className="text-lg font-semibold text-foreground mb-2 text-center">Lightning Fast</h3>
              <p className="text-foreground/70 text-center">Instant responses with advanced AI reasoning</p>
            </div>

            <div className="p-6 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm hover:border-purple-500/40 transition-all">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 mb-4 mx-auto" />
              <h3 className="text-lg font-semibold text-foreground mb-2 text-center">Private & Secure</h3>
              <p className="text-foreground/70 text-center">End-to-end encrypted conversations</p>
            </div>

            <div className="p-6 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm hover:border-purple-500/40 transition-all">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 mb-4 mx-auto" />
              <h3 className="text-lg font-semibold text-foreground mb-2 text-center">Unrestricted AI</h3>
              <p className="text-foreground/70 text-center">Advanced capabilities for deep analysis</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/30 backdrop-blur-md bg-background/50 py-6">
        <div className="container mx-auto px-4 text-center text-foreground/60 text-sm">
          <p>GoldenEagle-ai.developers - Powered by Advanced AI Technology</p>
        </div>
      </footer>
    </div>
  );
}
