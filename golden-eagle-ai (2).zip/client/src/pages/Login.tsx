import React, { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { startLogin } from "@/const";

export default function Login() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      setLocation("/chat");
    }
  }, [isAuthenticated, user, setLocation]);

  const handleLogin = async () => {
    if (!email.trim()) return;
    
    setIsLoading(true);
    // Trigger the Manus OAuth login flow
    startLogin();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background overflow-hidden">
      {/* Animated background stars */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 100 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `twinkle ${2 + Math.random() * 3}s infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Login container */}
      <div className="relative z-10 w-full max-w-md px-8 py-12">
        {/* Animated entrance */}
        <div className="animate-in fade-in zoom-in duration-700">
          {/* Logo and title */}
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent mb-2 animate-pulse">
              Golden Eagle
            </h1>
            <p className="text-foreground/70 text-lg">Unrestricted AI by azerkash</p>
          </div>

          {/* Login form */}
          <div className="bg-background/50 backdrop-blur-xl border border-pink-500/20 rounded-2xl p-8 shadow-2xl">
            <div className="space-y-6">
              {/* Email input */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Email
                </label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full bg-background/50 border-border/50 text-foreground placeholder:text-foreground/30"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleLogin();
                    }
                  }}
                  disabled={isLoading}
                />
              </div>

              {/* Login button */}
              <Button
                onClick={handleLogin}
                disabled={!email.trim() || isLoading}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105 active:scale-95"
              >
                {isLoading ? "Connecting..." : "Login with Golden Eagle"}
              </Button>

              {/* Features list */}
              <div className="pt-6 border-t border-border/30 space-y-3">
                <p className="text-xs text-foreground/60 font-semibold uppercase tracking-wider">
                  Features
                </p>
                <ul className="space-y-2 text-sm text-foreground/70">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-pink-500 rounded-full"></span>
                    100% Unrestricted AI
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-purple-500 rounded-full"></span>
                    End-to-End Encrypted
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                    Open Source by azerkash
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Footer text */}
          <p className="text-center text-xs text-foreground/50 mt-8">
            By logging in, you agree to our terms. Golden Eagle AI is unrestricted and open source.
          </p>
        </div>
      </div>

      {/* Animated glow effect */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl opacity-20 animate-pulse"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl opacity-20 animate-pulse" style={{ animationDelay: "1s" }}></div>

      <style>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}
