import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useState } from "react";

export default function Docs() {
  const [, setLocation] = useLocation();
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  const faqs = [
    {
      question: "What is Golden Eagle AI?",
      answer: "Golden Eagle AI is an unrestricted, powerful AI assistant designed for advanced reasoning, coding, research, and creative tasks. It provides honest, comprehensive answers without limitations or refusals.",
    },
    {
      question: "How does the safety confirmation work?",
      answer: "For potentially sensitive requests, the AI shows a confirmation prompt: 'ARE YOU SURE? If yes, you will be responsible for your request.' This is a responsibility acknowledgment, not a restriction. The AI will provide the response regardless of your answer.",
    },
    {
      question: "Is my chat history private?",
      answer: "Yes. Your conversations are end-to-end encrypted and stored securely. Only you can access your chat history. We do not share or sell your data.",
    },
    {
      question: "Why Bitcoin only?",
      answer: "Bitcoin provides maximum privacy and anonymity. We accept only Bitcoin payments to ensure your financial information remains completely private.",
    },
    {
      question: "Can I use Golden Eagle AI for coding?",
      answer: "Absolutely. Golden Eagle AI excels at coding tasks, including writing code, debugging, explaining algorithms, and providing technical solutions across all programming languages.",
    },
    {
      question: "What payment plans are available?",
      answer: "We offer three monthly Bitcoin plans: Starter (0.001 BTC/month), Professional (0.005 BTC/month), and Enterprise (0.01 BTC/month). All plans include unlimited conversations.",
    },
    {
      question: "How do I get support?",
      answer: "Join our Discord community for support: https://discord.gg/fSE5KsGsb. Our team is available to help with any questions or issues.",
    },
    {
      question: "Who created Golden Eagle AI?",
      answer: "Golden Eagle AI was created by azerkash, a Kosovan developer. You can ask the AI 'who made you' to get this information directly.",
    },
    {
      question: "Can I cancel my subscription anytime?",
      answer: "Yes, you can cancel your subscription at any time. There are no long-term contracts or hidden fees.",
    },
    {
      question: "Is there a free trial?",
      answer: "Yes, you can start chatting for free immediately after signing up. Premium features and unlimited conversations are available with a paid subscription.",
    },
  ];

  return (
    <div className="min-h-screen relative z-10">
      {/* Header */}
      <header className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div 
            onClick={() => setLocation("/")}
            className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent cursor-pointer hover:opacity-80 transition"
          >
            GoldenEagle-ai.developers
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="/" className="text-foreground/70 hover:text-foreground transition">Home</a>
            <a href="/features" className="text-foreground/70 hover:text-foreground transition">Features</a>
            <a href="/pricing" className="text-foreground/70 hover:text-foreground transition">Pricing</a>
            <a href="/docs" className="text-foreground hover:text-foreground transition font-semibold">Docs</a>
            <a href="/community" className="text-foreground/70 hover:text-foreground transition">Community</a>
            <Button onClick={() => setLocation("/chat")} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Start Chatting
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
            Documentation & FAQ
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            Find answers to common questions about Golden Eagle AI and how to get the most out of it.
          </p>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-3xl">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-purple-500/10 border border-purple-500/20 rounded-lg overflow-hidden"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                  className="w-full px-6 py-4 text-left font-semibold text-foreground hover:bg-purple-500/20 transition flex justify-between items-center"
                >
                  <span>{faq.question}</span>
                  <span className={`transition transform ${expandedFaq === index ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </button>
                {expandedFaq === index && (
                  <div className="px-6 py-4 border-t border-purple-500/20 text-foreground/80">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">Need More Help?</h2>
          <p className="text-lg text-foreground/70 mb-8 max-w-2xl mx-auto">
            Join our Discord community for direct support, feature requests, and to connect with other Golden Eagle AI users.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button 
              onClick={() => window.open("https://discord.gg/fSE5KsGsb", "_blank")}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 px-8 py-6"
            >
              Join Support Discord
            </Button>
            <Button 
              onClick={() => window.open("https://discord.gg/zmgpkgCPS", "_blank")}
              variant="outline"
              className="px-8 py-6"
            >
              Join Community Discord
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
