import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function Community() {
  const [, setLocation] = useLocation();

  const communityLinks = [
    {
      title: "Main Community Discord",
      description: "Join our vibrant community of Golden Eagle AI users, share ideas, and connect with others.",
      link: "https://discord.gg/zmgpkgCPS",
      color: "from-blue-500 to-cyan-500",
    },
    {
      title: "Support & Help Discord",
      description: "Get direct support from our team, report issues, and get help with any questions.",
      link: "https://discord.gg/fSE5KsGsb",
      color: "from-purple-500 to-pink-500",
    },
  ];

  return (
    <div className="min-h-screen relative z-10">
      {/* Header */}
      <header className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div 
            onClick={() => setLocation("/")}
            className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent cursor-pointer hover:opacity-80 transition"
          >
            GoldenEagle-ai.developers
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="/" className="text-foreground/70 hover:text-foreground transition">Home</a>
            <a href="/features" className="text-foreground/70 hover:text-foreground transition">Features</a>
            <a href="/pricing" className="text-foreground/70 hover:text-foreground transition">Pricing</a>
            <a href="/docs" className="text-foreground/70 hover:text-foreground transition">Docs</a>
            <a href="/community" className="text-foreground hover:text-foreground transition font-semibold">Community</a>
            <Button onClick={() => setLocation("/chat")} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Start Chatting
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
            Join Our Community
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            Connect with other Golden Eagle AI users, share experiences, get support, and stay updated on new features.
          </p>
        </div>
      </section>

      {/* Community Links */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
            {communityLinks.map((item, index) => (
              <div
                key={index}
                className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8 hover:border-purple-500/40 transition hover:bg-purple-500/15"
              >
                <h3 className="text-2xl font-bold text-foreground mb-4">{item.title}</h3>
                <p className="text-foreground/70 mb-6">{item.description}</p>
                <Button 
                  onClick={() => window.open(item.link, "_blank")}
                  className={`w-full bg-gradient-to-r ${item.color} hover:opacity-90`}
                >
                  Join Discord
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Benefits */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-foreground">Community Benefits</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-6">
              <div className="text-4xl mb-4">💬</div>
              <h3 className="text-lg font-bold text-foreground mb-2">Direct Support</h3>
              <p className="text-foreground/70">Get help from our team and experienced community members.</p>
            </div>
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-6">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="text-lg font-bold text-foreground mb-2">Feature Requests</h3>
              <p className="text-foreground/70">Suggest new features and vote on what you want to see next.</p>
            </div>
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-6">
              <div className="text-4xl mb-4">👥</div>
              <h3 className="text-lg font-bold text-foreground mb-2">Connect & Share</h3>
              <p className="text-foreground/70">Share tips, tricks, and use cases with fellow users.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">Ready to Join?</h2>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button 
              onClick={() => window.open("https://discord.gg/zmgpkgCPS", "_blank")}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 px-8 py-6 text-lg"
            >
              Join Community
            </Button>
            <Button 
              onClick={() => window.open("https://discord.gg/fSE5KsGsb", "_blank")}
              className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 px-8 py-6 text-lg"
            >
              Get Support
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
