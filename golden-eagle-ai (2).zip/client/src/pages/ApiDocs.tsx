import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function ApiDocs() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen relative z-10">
      {/* Header */}
      <header className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div 
            onClick={() => setLocation("/")}
            className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent cursor-pointer hover:opacity-80 transition"
          >
            GoldenEagle-ai.developers
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="/" className="text-foreground/70 hover:text-foreground transition">Home</a>
            <a href="/features" className="text-foreground/70 hover:text-foreground transition">Features</a>
            <a href="/pricing" className="text-foreground/70 hover:text-foreground transition">Pricing</a>
            <a href="/docs" className="text-foreground/70 hover:text-foreground transition">Docs</a>
            <a href="/api-docs" className="text-foreground hover:text-foreground transition font-semibold">API</a>
            <a href="/community" className="text-foreground/70 hover:text-foreground transition">Community</a>
            <Button onClick={() => setLocation("/chat")} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Start Chatting
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
            API Documentation
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            Build with Golden Eagle AI. Access our unrestricted AI through a simple, powerful API.
          </p>
        </div>
      </section>

      {/* API Endpoints */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold mb-12 text-foreground">API Endpoints</h2>

          {/* Chat Endpoint */}
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">Send Message</h3>
            <div className="bg-black/30 rounded p-4 mb-4 overflow-x-auto">
              <code className="text-green-400 font-mono text-sm">
                POST /api/trpc/chat.sendMessage
              </code>
            </div>
            
            <h4 className="text-lg font-semibold text-foreground mb-2">Request Body</h4>
            <div className="bg-black/30 rounded p-4 mb-4 overflow-x-auto">
              <code className="text-foreground/80 font-mono text-sm">
{`{
  "message": "Your question here",
  "confirmed": false
}`}
              </code>
            </div>

            <h4 className="text-lg font-semibold text-foreground mb-2">Response</h4>
            <div className="bg-black/30 rounded p-4 overflow-x-auto">
              <code className="text-foreground/80 font-mono text-sm">
{`{
  "response": "AI response text",
  "isSensitive": false,
  "requiresConfirmation": false
}`}
              </code>
            </div>
          </div>

          {/* Chat History Endpoint */}
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">Get Chat History</h3>
            <div className="bg-black/30 rounded p-4 mb-4 overflow-x-auto">
              <code className="text-green-400 font-mono text-sm">
                GET /api/trpc/chat.getChatHistory
              </code>
            </div>
            
            <h4 className="text-lg font-semibold text-foreground mb-2">Response</h4>
            <div className="bg-black/30 rounded p-4 overflow-x-auto">
              <code className="text-foreground/80 font-mono text-sm">
{`[
  {
    "id": 1,
    "userId": 123,
    "role": "user",
    "content": "Your message",
    "encrypted": 1,
    "createdAt": "2026-07-08T18:00:00Z"
  },
  {
    "id": 2,
    "userId": 123,
    "role": "assistant",
    "content": "AI response",
    "encrypted": 1,
    "createdAt": "2026-07-08T18:00:05Z"
  }
]`}
              </code>
            </div>
          </div>

          {/* Authentication */}
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">Authentication</h3>
            <p className="text-foreground/80 mb-4">
              All API requests require authentication via OAuth. Include your session cookie with requests.
            </p>
            <div className="bg-black/30 rounded p-4 overflow-x-auto">
              <code className="text-foreground/80 font-mono text-sm">
                Cookie: session=your_session_token
              </code>
            </div>
          </div>

          {/* Rate Limiting */}
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">Rate Limiting</h3>
            <p className="text-foreground/80">
              Free tier: 10 requests per minute. Premium tiers include higher limits. Rate limit information is returned in response headers.
            </p>
          </div>
        </div>
      </section>

      {/* Code Examples */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold mb-12 text-foreground">Code Examples</h2>

          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">JavaScript/TypeScript</h3>
            <div className="bg-black/30 rounded p-4 overflow-x-auto">
              <code className="text-foreground/80 font-mono text-sm">
{`const response = await fetch('/api/trpc/chat.sendMessage', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    message: 'What is Golden Eagle AI?',
    confirmed: false
  })
});

const data = await response.json();
console.log(data.response);`}
              </code>
            </div>
          </div>
        </div>
      </section>

      {/* Support */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">Need Help?</h2>
          <Button 
            onClick={() => window.open("https://discord.gg/fSE5KsGsb", "_blank")}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 px-8 py-6"
          >
            Join Support Discord
          </Button>
        </div>
      </section>
    </div>
  );
}
