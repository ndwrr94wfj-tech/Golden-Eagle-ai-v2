import React from "react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function About() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col relative z-10">
      {/* Header */}
      <header className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <button
            onClick={() => setLocation("/")}
            className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent hover:opacity-80 transition-opacity"
          >
            GoldenEagle-ai.developers
          </button>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => setLocation("/pricing")}
              className="text-foreground/80 hover:text-foreground transition-colors"
            >
              Pricing
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <section className="flex-1 px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-8 bg-gradient-to-r from-purple-300 via-pink-300 to-purple-500 bg-clip-text text-transparent">
            About Golden Eagle AI
          </h1>

          <div className="space-y-8 text-foreground/80 text-lg leading-relaxed">
            <div className="p-8 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-foreground mb-4">Our Mission</h2>
              <p>
                Golden Eagle AI is built on the principle that advanced artificial intelligence should be accessible, unrestricted, and private. We believe in empowering users with powerful tools while maintaining their privacy and security.
              </p>
            </div>

            <div className="p-8 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-foreground mb-4">Privacy First</h2>
              <p>
                All conversations are end-to-end encrypted. Your data never leaves your device unencrypted. We use Bitcoin for payments to ensure maximum financial privacy. We cannot access your conversations even if we wanted to.
              </p>
            </div>

            <div className="p-8 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-foreground mb-4">Advanced AI</h2>
              <p>
                Golden Eagle AI is powered by state-of-the-art language models. Our AI is designed to provide unrestricted responses while maintaining safety through user confirmation for sensitive requests. You are responsible for how you use the AI.
              </p>
            </div>

            <div className="p-8 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-foreground mb-4">Creator</h2>
              <p>
                Golden Eagle AI was created by azerkash, a Kosovan developer passionate about building powerful, privacy-respecting AI tools. The platform represents a vision of what AI should be: intelligent, unrestricted, and private.
              </p>
            </div>

            <div className="p-8 rounded-lg border border-purple-500/20 bg-purple-500/5 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-foreground mb-4">Responsible Use</h2>
              <p>
                While Golden Eagle AI is unrestricted, users are responsible for their requests. Before processing potentially sensitive requests, the AI will ask for confirmation. By using this platform, you acknowledge that you are responsible for your actions and requests.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <Button
              onClick={() => setLocation("/")}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 px-8 py-6 text-lg font-bold"
            >
              Get Started
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/30 backdrop-blur-md bg-background/50 py-6">
        <div className="container mx-auto px-4 text-center text-foreground/60 text-sm">
          <p>GoldenEagle-ai.developers - Built with privacy and power in mind</p>
        </div>
      </footer>
    </div>
  );
}
