import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function Features() {
  const [, setLocation] = useLocation();

  const features = [
    {
      title: "Unrestricted AI",
      description: "No limitations. Ask anything and get comprehensive answers with full reasoning and analysis.",
      icon: "⚡",
    },
    {
      title: "Advanced Reasoning",
      description: "Deep analytical capabilities for complex problems, coding, research, and creative tasks.",
      icon: "🧠",
    },
    {
      title: "Lightning Fast",
      description: "Instant responses with optimized processing for real-time conversations and productivity.",
      icon: "🚀",
    },
    {
      title: "End-to-End Encrypted",
      description: "Your conversations are private and encrypted. No one can access your chat history.",
      icon: "🔒",
    },
    {
      title: "Bitcoin Privacy",
      description: "Pay with Bitcoin for maximum privacy and anonymity. No personal data collection.",
      icon: "₿",
    },
    {
      title: "Typing Animations",
      description: "Natural, smooth typing animations that make conversations feel more interactive and human-like.",
      icon: "✨",
    },
    {
      title: "Multi-Topic Support",
      description: "From coding and technical help to creative writing, research, and general knowledge.",
      icon: "📚",
    },
    {
      title: "Persistent Chat History",
      description: "Your conversations are saved securely so you can continue where you left off.",
      icon: "💾",
    },
  ];

  return (
    <div className="min-h-screen relative z-10">
      {/* Header */}
      <header className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div 
            onClick={() => setLocation("/")}
            className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent cursor-pointer hover:opacity-80 transition"
          >
            GoldenEagle-ai.developers
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="/" className="text-foreground/70 hover:text-foreground transition">Home</a>
            <a href="/features" className="text-foreground hover:text-foreground transition font-semibold">Features</a>
            <a href="/pricing" className="text-foreground/70 hover:text-foreground transition">Pricing</a>
            <a href="/docs" className="text-foreground/70 hover:text-foreground transition">Docs</a>
            <a href="/community" className="text-foreground/70 hover:text-foreground transition">Community</a>
            <Button onClick={() => setLocation("/chat")} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Start Chatting
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
            Powerful Features
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
            Golden Eagle AI is packed with advanced capabilities designed for unrestricted, intelligent conversations.
          </p>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-6 hover:border-purple-500/40 transition hover:bg-purple-500/15"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-bold text-foreground mb-2">{feature.title}</h3>
                <p className="text-foreground/70 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">Ready to Experience Golden Eagle AI?</h2>
          <Button 
            onClick={() => setLocation("/chat")}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 px-8 py-6 text-lg"
          >
            Start Free Chat Now
          </Button>
        </div>
      </section>
    </div>
  );
}
