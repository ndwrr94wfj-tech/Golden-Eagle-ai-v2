import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState } from "react";

export default function Profile() {
  const { user, logout, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-foreground/60">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Please log in to view your profile</h1>
          <Button onClick={() => setLocation("/")} className="bg-gradient-to-r from-purple-500 to-pink-500">
            Go Home
          </Button>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen relative z-10">
      {/* Header */}
      <header className="border-b border-border/30 backdrop-blur-md bg-background/50 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div 
            onClick={() => setLocation("/")}
            className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent cursor-pointer hover:opacity-80 transition"
          >
            GoldenEagle-ai.developers
          </div>
          <nav className="hidden md:flex gap-8 items-center">
            <a href="/" className="text-foreground/70 hover:text-foreground transition">Home</a>
            <a href="/chat" className="text-foreground/70 hover:text-foreground transition">Chat</a>
            <a href="/pricing" className="text-foreground/70 hover:text-foreground transition">Pricing</a>
            <Button onClick={() => setLocation("/chat")} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Start Chatting
            </Button>
          </nav>
        </div>
      </header>

      {/* Profile Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-2xl">
          <h1 className="text-5xl font-bold mb-12 text-foreground">Your Profile</h1>

          {/* Profile Card */}
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8 mb-8">
            <div className="flex items-center gap-6 mb-8">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                <span className="text-3xl text-white">
                  {user.email?.[0]?.toUpperCase() || "U"}
                </span>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-foreground">{user.name || "User"}</h2>
                <p className="text-foreground/70">{user.email}</p>
                <p className="text-sm text-foreground/60 mt-2">
                  Role: <span className="font-semibold capitalize">{user.role}</span>
                </p>
              </div>
            </div>

            {/* Account Info */}
            <div className="space-y-4 border-t border-purple-500/20 pt-6">
              <div className="flex justify-between items-center">
                <span className="text-foreground/70">Account Status</span>
                <span className="text-green-400 font-semibold">Active</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-foreground/70">Member Since</span>
                <span className="text-foreground">
                  {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-foreground/70">Last Signed In</span>
                <span className="text-foreground">
                  {user.lastSignedIn ? new Date(user.lastSignedIn).toLocaleDateString() : "N/A"}
                </span>
              </div>
            </div>
          </div>

          {/* Settings Section */}
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-6">Settings</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-purple-500/5 rounded-lg">
                <span className="text-foreground">Privacy Settings</span>
                <Button variant="outline" size="sm">Configure</Button>
              </div>
              <div className="flex justify-between items-center p-4 bg-purple-500/5 rounded-lg">
                <span className="text-foreground">Notification Preferences</span>
                <Button variant="outline" size="sm">Configure</Button>
              </div>
              <div className="flex justify-between items-center p-4 bg-purple-500/5 rounded-lg">
                <span className="text-foreground">Security</span>
                <Button variant="outline" size="sm">Manage</Button>
              </div>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-red-400 mb-6">Danger Zone</h3>
            <Button 
              onClick={() => setShowLogoutConfirm(true)}
              variant="outline"
              className="border-red-500/30 text-red-400 hover:bg-red-500/10 w-full"
            >
              Logout
            </Button>
          </div>

          {/* Logout Confirmation Modal */}
          {showLogoutConfirm && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
              <div className="bg-card border border-purple-500/30 rounded-lg p-8 max-w-md mx-4 shadow-2xl">
                <h2 className="text-xl font-bold text-foreground mb-4">Confirm Logout</h2>
                <p className="text-foreground/80 mb-6">Are you sure you want to logout?</p>
                <div className="flex gap-4">
                  <Button
                    onClick={() => setShowLogoutConfirm(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleLogout}
                    className="flex-1 bg-red-500 hover:bg-red-600"
                  >
                    Logout
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
